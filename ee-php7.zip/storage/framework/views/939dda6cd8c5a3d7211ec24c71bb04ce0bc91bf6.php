<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
<h4><?php echo e($errors->first(), false); ?></h4>
<?php endif; ?>
<?php //$a =session()->get('tmp_social'); dd($a[0][0]); ?>
<div class="content home text-center" id="content">
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <div class="newpost">
                <a href="<?php echo e(route('hire'), false); ?>" class="btn btn-workers btn-thue" style="line-height: 94px;">Thuê lao động</a>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <div class="newpost">
                <a href="<?php echo e(route('worker'), false); ?>" class="btn btn-workers btn-nld" style="line-height: 94px;">Người lao động</a>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>