<?php $__env->startSection('content'); ?>
<div class="content workers text-center" id="content">
	<div class="row">
		<div class="col-md-4 col-md-offset-4">
			<div class="newpost">
				<a href="<?php echo e(route('worker_createposts'), false); ?>" class="btn btn-workers btn-nld">Đăng tin</a>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-4 col-md-offset-4">
				<div class="newpost">
				<a href="<?php echo e(route('worker_listposts'), false); ?>" class="btn btn-workers btn-nld">Kho thông tin</a>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>