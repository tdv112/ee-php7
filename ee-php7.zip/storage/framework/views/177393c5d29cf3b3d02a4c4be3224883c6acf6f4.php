<?php $__env->startSection('content'); ?>

    
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css"
          integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous"
          xmlns="http://www.w3.org/1999/html">

    
    <div class="newpost" id="newpost">
        <div class="vipcontainer">
            <div class="row">
                
                <div class="col-sm-2 hidden-xs ads">
                    <ul class="list-unstyled">
                        <li>
                            <a href="">
                                <div class="card">
                                    <img class="card-img-top img-rounded img-responsive"
                                         src="/EE/images/ads.jpg" alt="Card image cap">
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <div class="card">
                                    <img class="card-img-top img-rounded img-responsive"
                                         src="/EE/images/ads.jpg" alt="Card image cap">
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <div class="card">
                                    <img class="card-img-top img-rounded img-responsive"
                                         src="/EE/images/ads.jpg" alt="Card image cap">
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <div class="card">
                                    <img class="card-img-top img-rounded img-responsive"
                                         src="/EE/images/ads.jpg" alt="Card image cap">
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <div class="card">
                                    <img class="card-img-top img-rounded img-responsive"
                                         src="/EE/images/ads.jpg" alt="Card image cap">
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <div class="card">
                                    <img class="card-img-top img-rounded img-responsive"
                                         src="/EE/images/ads.jpg" alt="Card image cap">
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>
                
                <div class="col-md-7 contentpost">
                    
                    <div class="row" id="icon-view">
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-6 col-md-4">
                            <div class="thumbnail">
                                <img src="/EE/images/ads.jpg" alt="...">
                                <div class="caption">
                                    <h5 style="word-wrap: break-word;"><?php echo e($element->post_title, false); ?></h5>
                                    <p>Ngày đăng : <?php echo e(date("d-m-Y", strtotime($element->created_at)), false); ?></p>  
                                </div>
                                <div class="text-center">
                                    <a href="/edit-post/<?php echo e($element->id, false); ?>" class="btn btn-primary" role="button">Sửa</a> 
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                
                <div class="col-sm-3 right-banner-ads" style="">
                    <div class="categorys" style="height: 10rem; background-color: #CCCCCC;">
                        Banner ADS
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>


<script type="text/javascript" src="<?php echo e(asset('EE/js/jquery.min.js'), false); ?>"></script>





<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>